/*! licenses: /vendor.LICENSE.txt */
import{ai as n,ah as r,b3 as a,ag as i}from"./main-BLTVzlej.js";function s(t){return n("/api/project_links/search",{projectKey:t}).then(e=>e.links,r)}function c(t){return i("/api/project_links/delete",{id:t}).catch(r)}function p(t){return a("/api/project_links/create",t).then(e=>e.link,r)}export{p as c,c as d,s as g};
//# sourceMappingURL=projectLinks-6Il15ym9.js.map
