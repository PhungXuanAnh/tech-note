/*! licenses: /vendor.LICENSE.txt */
import{j as a}from"./echoes-BfeGX--x.js";import"./vendor-C8omvz16.js";import{dQ as i,ad as e}from"./main-BLTVzlej.js";function s({className:t}){return a.jsx(i,{className:t,"data-component":"built-in-quality-gate-badge",children:e("quality_gates.built_in")})}export{s as B};
//# sourceMappingURL=BuiltInQualityGateBadge-MrpJGcUB.js.map
