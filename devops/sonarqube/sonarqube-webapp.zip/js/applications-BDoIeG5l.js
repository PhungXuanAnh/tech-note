/*! licenses: /vendor.LICENSE.txt */
import{aj as n,ak as o,al as s,am as u,hM as i}from"./main-BLTVzlej.js";import{a as r,d as p}from"./application-C_vGoo-q.js";const y=n(e=>o({queryKey:["application","leak",e],queryFn:()=>r(e)}));function m(){const e=s();return u({mutationFn:a=>p(a),onSuccess:(a,t)=>{i(t,e)}})}export{m as a,y as u};
//# sourceMappingURL=applications-BDoIeG5l.js.map
