/*! licenses: /vendor.LICENSE.txt */
import{E as e}from"./echoes-BfeGX--x.js";import{co as s}from"./main-BLTVzlej.js";function n(r){return r instanceof Response?s(r).then(o=>{e.error({description:o,duration:"short"})},()=>{}):typeof r=="string"?Promise.resolve(r).then(o=>{e.error({description:o,duration:"short"})}):Promise.resolve()}export{n as a};
//# sourceMappingURL=globalMessages-Dn8d3fiL.js.map
