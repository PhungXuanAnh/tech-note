/*! licenses: /vendor.LICENSE.txt */
function e(t,r){const a=new URLSearchParams({project:t});return r&&a.append("branch",r),`/api/regulatory_reports/download?${a.toString()}`}export{e as g};
//# sourceMappingURL=regulatory-report-DyU2owDO.js.map
