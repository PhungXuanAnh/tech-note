/*! licenses: /vendor.LICENSE.txt */
let t=function(e){return e.Success="SUCCESS",e.Failed="FAILED",e}({}),I=function(e){return e.jit="JIT",e.auto="AUTO_PROVISIONING",e}({});export{t as G,I as P};
//# sourceMappingURL=provisioning-DzvtFEq8.js.map
