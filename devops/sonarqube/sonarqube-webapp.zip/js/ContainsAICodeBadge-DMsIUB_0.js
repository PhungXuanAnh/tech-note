/*! licenses: /vendor.LICENSE.txt */
import{j as a,a4 as s,b9 as t,M as r}from"./echoes-BfeGX--x.js";import{a as i}from"./vendor-C8omvz16.js";const d=i.forwardRef((e,o)=>a.jsx(s,{...e,IconLeft:t,ref:o,variety:"highlight",children:a.jsx(r,{id:"contains_ai_code"})}));d.displayName="ContainsAICodeBadge";export{d as C};
//# sourceMappingURL=ContainsAICodeBadge-DMsIUB_0.js.map
