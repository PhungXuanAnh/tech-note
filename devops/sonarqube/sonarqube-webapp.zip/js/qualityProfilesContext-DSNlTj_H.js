/*! licenses: /vendor.LICENSE.txt */
import{az as s}from"./main-BLTVzlej.js";import{j as n}from"./echoes-BfeGX--x.js";import{s as e}from"./vendor-C8omvz16.js";function p(t){function o(i){const r=e();return n.jsx(t,{...i,...r,"data-component":"component-with-quality-profiles-props"})}return o.displayName=s(t,"withQualityProfilesContext"),o}function f(){return e()}export{f as u,p as w};
//# sourceMappingURL=qualityProfilesContext-DSNlTj_H.js.map
