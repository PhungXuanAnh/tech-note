/*! licenses: /vendor.LICENSE.txt */
import{j as n}from"./echoes-BfeGX--x.js";import"./vendor-C8omvz16.js";import{av as a,k4 as e}from"./main-BLTVzlej.js";function f({name:o,language:t,children:r,...i}){return n.jsx(a,{to:e(o,t),...i,"data-component":"profile-link",children:r})}export{f as P};
//# sourceMappingURL=ProfileLink-CG11z5a3.js.map
